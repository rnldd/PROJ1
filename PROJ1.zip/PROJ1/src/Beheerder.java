public class Beheerder extends Gebruiker {

    public Beheerder(int gebruikersID) {
        super(gebruikersID); // Roep de constructor van de superklasse aan met het gebruikersID
    }
    public void verwijderReview(int reviewID){
        // TODO logica voor verwijderen van review uit lijst game reviews
    }
}
